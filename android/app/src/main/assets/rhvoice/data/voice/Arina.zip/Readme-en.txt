License
This voice is distributed under the Creative Commons Attribution-NonCommercial-NoDerivatives 4.0 International Public License: https://creativecommons.org/licenses/by-nc-nd/4.0/

You can send a request for integration of voice into any product to the laboratory's e-mail address. If the approval is given by the speaker and our team you will get the appropriate permission.

Team
Artem Plaksin AKA maniyax — general leadership
Sergey Parshakov AKA Electrik — Editing of speaker recordings
Denis Shishkin AKA Outsider — sound processing
Beka Gozalishvili AKA Gozaltech — voice training

Speaker: Arina Syukkya (event planner, designer)

Contact us
E-mail: rhvoice@tiflo.org
Phone: +7 (952) 280-89-89
Website: https://rhvoice.su
